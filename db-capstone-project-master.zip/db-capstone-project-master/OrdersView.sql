create view OrdersView AS
select OrderID,OrderQuantity,TotalCost FROM Orders;
