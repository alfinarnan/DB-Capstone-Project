setting up repository for project
